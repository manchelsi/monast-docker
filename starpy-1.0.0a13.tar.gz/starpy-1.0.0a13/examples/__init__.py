"""Example applications for usage of StarPy with Asterisk"""
